fotochop
========

haskell application for applying filters to an image